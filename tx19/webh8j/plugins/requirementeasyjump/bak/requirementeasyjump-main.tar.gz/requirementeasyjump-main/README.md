# RequirementEasyJump

a javascript run in edge browser. This script can turn the requirement text into corresponding hyperlink to facilitate jumping on gates.

# start
## step1 
download this project

## step2 
### 2.1 open edge browser，input edge://extensions in address bar
### 2.2 open Developer mode
### 2.3 click "Load unpacked" button, select this project file.

# Test
open gates https://gates.nsn-net.net/view/00025da1#o=0 to test it.
